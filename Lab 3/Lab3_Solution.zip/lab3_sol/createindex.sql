CREATE INDEX LookUpSales ON Sales(customerID, dayDate);

-- Results:
-- lab1test=> \i createindex.sql
-- CREATE INDEX